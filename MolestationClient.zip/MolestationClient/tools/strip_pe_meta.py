#!/usr/bin/env python3
"""
strip_pe_meta.py  <exe_path>

Post-build PE scrubber. Zeroes out:
  - PE timestamp in COFF header         (offset 8 in PE header)
  - PE checksum in optional header       (offset 64 from PE opt header start)
  - Rich header (DOS stub region between DOS header and PE sig)
  - Debug directory entries              (strips path/GUID from IMAGE_DEBUG_TYPE_CODEVIEW)

Does NOT break the binary — just removes toolchain fingerprint fields.
No external deps beyond Python stdlib.
"""
import sys, struct, os

def u32(data, off): return struct.unpack_from('<I', data, off)[0]
def w32(ba, off, val): struct.pack_into('<I', ba, off, val)

def strip(path):
    with open(path, 'rb') as f:
        raw = bytearray(f.read())

    # --- locate PE header ---
    if raw[0:2] != b'MZ':
        print(f"[strip_pe_meta] not a PE: {path}")
        return

    pe_off = u32(raw, 0x3C)
    if raw[pe_off:pe_off+4] != b'PE\0\0':
        print(f"[strip_pe_meta] bad PE sig at {pe_off:#x}")
        return

    # --- zero COFF timestamp (PE+8) ---
    ts_off = pe_off + 8
    old_ts = u32(raw, ts_off)
    w32(raw, ts_off, 0)
    print(f"[strip_pe_meta] timestamp: {old_ts:#010x} -> 0")

    # --- zero checksum (PE + 4 + 20 + 64 = PE optional header + 0x40) ---
    coff_size = 20
    opt_off = pe_off + 4 + coff_size
    chk_off = opt_off + 64
    old_chk = u32(raw, chk_off)
    w32(raw, chk_off, 0)
    print(f"[strip_pe_meta] checksum: {old_chk:#010x} -> 0")

    # --- scrub Rich header ---
    # Rich header lives between DOS header (0x40) and PE sig (pe_off)
    # Signature: b'Rich' XOR'd with a DWORD key, preceded by b'DanS' marker
    dos_end = 0x40
    stub_region = bytes(raw[dos_end:pe_off])
    rich_tag = b'Rich'
    rich_pos = stub_region.find(rich_tag)
    if rich_pos != -1:
        abs_rich = dos_end + rich_pos
        # key is the DWORD after 'Rich'
        key = u32(raw, abs_rich + 4)
        # find DanS (= 'DanS' XOR key) to mark start
        dans = struct.pack('<I', u32(b'DanS', 0) ^ key) if False else struct.pack('<I', key ^ 0x536E6144)
        dans_pos = stub_region.find(dans)
        if dans_pos != -1:
            abs_dans = dos_end + dans_pos
            # zero from DanS through Rich + 8 (Rich sig + key dword)
            erase_end = abs_rich + 8
            for i in range(abs_dans, erase_end):
                raw[i] = 0
            print(f"[strip_pe_meta] Rich header zeroed ({abs_dans:#x} - {erase_end:#x})")
        else:
            # just zero the Rich tag + key
            for i in range(abs_rich, abs_rich + 8):
                raw[i] = 0
            print(f"[strip_pe_meta] Rich tag zeroed (DanS not found)")
    else:
        print("[strip_pe_meta] no Rich header found")

    # --- zero debug directory CodeView PDB path ---
    # Read data directories: opt_off + 96 (PE32+) or opt_off + 96 - 16 (PE32)
    magic = u32(raw, opt_off) & 0xFFFF
    dd_off = opt_off + (112 if magic == 0x20B else 96)  # PE32+ vs PE32
    debug_dd_off = dd_off + 6 * 8  # debug directory is entry 6
    debug_va  = u32(raw, debug_dd_off)
    debug_sz  = u32(raw, debug_dd_off + 4)

    if debug_va and debug_sz:
        # Find file offset from VA: scan section headers
        num_sections = struct.unpack_from('<H', raw, pe_off + 6)[0]
        sec_off = opt_off + struct.unpack_from('<H', raw, pe_off + 20)[0]
        def va_to_off(va):
            for i in range(num_sections):
                s = sec_off + i * 40
                virt_addr = u32(raw, s + 12)
                virt_size = u32(raw, s + 16)
                raw_off   = u32(raw, s + 20)
                if virt_addr <= va < virt_addr + virt_size:
                    return raw_off + (va - virt_addr)
            return None
        dbg_file_off = va_to_off(debug_va)
        if dbg_file_off:
            entry_count = debug_sz // 28
            for i in range(entry_count):
                entry = dbg_file_off + i * 28
                dbg_type = u32(raw, entry + 12)
                data_size = u32(raw, entry + 16)
                data_va   = u32(raw, entry + 20)
                data_off  = u32(raw, entry + 24)
                if dbg_type == 2 and data_off and data_size:  # IMAGE_DEBUG_TYPE_CODEVIEW
                    # zero the CV record (RSDS sig + GUID + age + path)
                    for j in range(min(data_size, 512)):
                        raw[data_off + j] = 0
                    print(f"[strip_pe_meta] CodeView debug record zeroed ({data_size} bytes @ {data_off:#x})")
                # zero the debug directory entry timestamps too
                w32(raw, entry + 4, 0)

    with open(path, 'wb') as f:
        f.write(raw)
    print(f"[strip_pe_meta] done: {os.path.basename(path)}")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("usage: strip_pe_meta.py <exe>")
        sys.exit(1)
    strip(sys.argv[1])
