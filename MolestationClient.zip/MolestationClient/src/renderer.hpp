#pragma once
#include "settings.hpp"
#include "provider.hpp"
#include "imgui.h"
#include "avatar.hpp"

namespace ext {
void setTheme();
inline ImVec2 menuSize(ImVec2 display){return {std::max(1.f,std::min(980.f,display.x-28)),std::max(1.f,std::min(730.f,display.y-28))};}
void drawOverlay(const Snapshot& s,const Settings& cfg,float width,float height,Vec2 cursor,
                 const std::optional<Target>& target,bool holding,float fps);
void drawMenu(Settings& cfg,Provider& provider,const Snapshot& snapshot,
              const std::filesystem::path& folder,const std::string& inputStatus,const std::string& recoilStatus,const AvatarView& avatar,bool& running);
}
