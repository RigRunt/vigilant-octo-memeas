#pragma once
#include "core.hpp"
#include <mutex>
#include <memory>

namespace ext {
class SnapshotStore {
    mutable std::mutex mutex_;
    std::shared_ptr<const Snapshot> value_=std::make_shared<const Snapshot>();
    int mode_=0;
    uint64_t revision_=0;
    bool reloadPending_=true;
    void invalidate(const char* message) {
        ++revision_;
        reloadPending_=true;
        Snapshot next;next.revision=revision_;next.demo=mode_==1;next.status=message;
        value_=std::make_shared<const Snapshot>(std::move(next));
    }
public:
    struct Request { int mode; uint64_t revision; bool reload; };
    Snapshot snapshot() const { std::lock_guard<std::mutex> lock(mutex_);return *value_; }
    std::shared_ptr<const Snapshot> sharedSnapshot() const {std::lock_guard<std::mutex> lock(mutex_);return value_;}
    int mode() const { std::lock_guard<std::mutex> lock(mutex_);return mode_; }
    uint64_t revision() const { std::lock_guard<std::mutex> lock(mutex_);return revision_; }
    void setMode(int mode) {
        std::lock_guard<std::mutex> lock(mutex_);
        if(mode<0||mode>1) return;
        mode_=mode;
        invalidate(mode==1?"Switching to demo; mouse output disabled":"Switching to live; awaiting validated data");
    }
    void reload() {
        std::lock_guard<std::mutex> lock(mutex_);
        invalidate("Reload requested; mouse output paused");
    }
    Request consumeRequest() {
        std::lock_guard<std::mutex> lock(mutex_);
        Request result{mode_,revision_,reloadPending_};reloadPending_=false;return result;
    }
    bool publish(Snapshot snapshot,uint64_t revision) {
        std::lock_guard<std::mutex> lock(mutex_);
        if(revision!=revision_||snapshot.demo!=(mode_==1)) return false;
        snapshot.revision=revision;
        value_=std::make_shared<const Snapshot>(std::move(snapshot));return true;
    }
};
}
