#pragma once
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <limits>
#include <optional>
#include <string>
#include <vector>

namespace ext {
using Clock = std::chrono::steady_clock;
struct Vec2 { float x=0, y=0; };
struct Vec3 {
    float x=0, y=0, z=0;
    Vec3 operator+(Vec3 b) const { return {x+b.x,y+b.y,z+b.z}; }
    Vec3 operator-(Vec3 b) const { return {x-b.x,y-b.y,z-b.z}; }
    Vec3 operator*(float f) const { return {x*f,y*f,z*f}; }
};
inline bool finite(Vec2 v) { return std::isfinite(v.x)&&std::isfinite(v.y); }
inline bool viewportValid(float w,float h) { return std::isfinite(w)&&std::isfinite(h)&&w>0&&h>0; }
inline bool finite(Vec3 v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z); }
inline float length(Vec3 v) { return std::hypot(v.x,v.y,v.z); }
inline float distance(Vec2 a, Vec2 b) { return std::hypot(a.x-b.x,a.y-b.y); }
struct Mat3 {
    float m[9]{1,0,0,0,1,0,0,0,1};
    Vec3 apply(Vec3 v) const {
        return {m[0]*v.x+m[1]*v.y+m[2]*v.z,
                m[3]*v.x+m[4]*v.y+m[5]*v.z,
                m[6]*v.x+m[7]*v.y+m[8]*v.z};
    }
};
struct Mat4 { float m[16]{}; };
struct Clip { float x=0,y=0,w=0; };
inline Clip clip(const Mat4& mat, Vec3 v) {
    const auto* m=mat.m;
    return {m[0]*v.x+m[1]*v.y+m[2]*v.z+m[3],
            m[4]*v.x+m[5]*v.y+m[6]*v.z+m[7],
            m[12]*v.x+m[13]*v.y+m[14]*v.z+m[15]};
}
inline std::optional<Vec2> project(const Mat4& mat, Vec3 v, float width, float height) {
    if (!finite(v)||!viewportValid(width,height)) return {};
    auto c=clip(mat,v);
    if (!std::isfinite(c.w)||!std::isfinite(c.x)||!std::isfinite(c.y)||c.w<0.01f) return {};
    Vec2 p{width*0.5f*(1+c.x/c.w),height*0.5f*(1-c.y/c.w)};
    if (!std::isfinite(p.x)||!std::isfinite(p.y)) return {};
    return p;
}
inline bool onScreen(Vec2 p, float w, float h) { return finite(p)&&viewportValid(w,h)&&p.x>=0&&p.y>=0&&p.x<w&&p.y<h; }
enum Bone : int { Head, Torso, Pelvis, LUpperArm, LLowerArm, LHand, RUpperArm, RLowerArm, RHand,
                 LUpperLeg, LLowerLeg, LFoot, RUpperLeg, RLowerLeg, RFoot, Root, BoneCount };
inline constexpr std::array<std::array<int,2>,15> Skeleton{{
    {Head,Torso},{Torso,Pelvis},{Torso,LUpperArm},{LUpperArm,LLowerArm},{LLowerArm,LHand},
    {Torso,RUpperArm},{RUpperArm,RLowerArm},{RLowerArm,RHand},{Pelvis,LUpperLeg},
    {LUpperLeg,LLowerLeg},{LLowerLeg,LFoot},{Pelvis,RUpperLeg},{RUpperLeg,RLowerLeg},
    {RLowerLeg,RFoot},{Pelvis,Root}
}};
struct Part {
    Vec3 position{},size{};
    Mat3 rotation{};
    bool valid=false;
    std::array<Vec3,8> corners() const {
        std::array<Vec3,8> out{};
        for (int i=0;i<8;++i) out[i]=position+rotation.apply({(i&1?1.f:-1.f)*size.x*0.5f,
            (i&2?1.f:-1.f)*size.y*0.5f,(i&4?1.f:-1.f)*size.z*0.5f});
        return out;
    }
};
struct Entity {
    uint64_t id=0,team=0;
    std::string name,teamName;
    float health=0,maxHealth=100;
    Vec3 velocity{};
    std::array<Part,BoneCount> parts{};
    std::vector<Part> geometry;
};
struct Snapshot {
    bool valid=false,demo=false;
    uint32_t pid=0;
    uint64_t revision=0;
    uintptr_t targetWindow=0;
    std::string status="Waiting for Roblox",version,localName;
    Mat4 view{};
    Vec3 camera{},localPosition{};
    uint64_t localTeam=0,localUserId=0;
    float cameraYaw=0;
    std::vector<Entity> entities;
    Clock::time_point sampled=Clock::now();
};
struct Bounds { float left=0,top=0,right=0,bottom=0; };
inline std::optional<Bounds> bounds(const Entity& e,const Mat4& mat,float w,float h) {
    Bounds b{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),
             std::numeric_limits<float>::lowest(),std::numeric_limits<float>::lowest()};
    int count=0;
    auto consume=[&](const auto& pieces) { for (const auto& part:pieces) if (part.valid) {
        auto center=project(mat,part.position,w,h);
        if (!center) continue;
        for (auto v:part.corners()) if (auto p=project(mat,v,w,h)) {
            b.left=std::min(b.left,p->x); b.right=std::max(b.right,p->x);
            b.top=std::min(b.top,p->y); b.bottom=std::max(b.bottom,p->y); ++count;
        }
    }};
    if(e.geometry.empty()) consume(e.parts);else consume(e.geometry);
    if (count<2||b.right-b.left<1||b.bottom-b.top<1||b.right<0||b.left>w||b.bottom<0||b.top>h||
        b.right-b.left>w*4||b.bottom-b.top>h*4) return {};
    return b;
}
struct AimOptions {
    bool enabled=false,teamCheck=true,sticky=true,prediction=false;
    int bone=0,priority=0,inputMode=0,origin=0,activation=0;
    float radius=160,smoothingMs=85,gain=1,maxStep=35,maxDistance=1500,leadMs=65;
    float deadzone=1.5f,maxSpeed=1200,axisX=1,axisY=1,switchDelayMs=0,minHealth=0;
};
struct Target { uint64_t id=0; Vec2 screen{}; Vec3 world{}; float screenDistance=0,worldDistance=0; };
inline std::optional<Target> selectTarget(const Snapshot& s,const AimOptions& o,Vec2 origin,
                                        float w,float h,uint64_t previous=0) {
    if(!s.valid||!viewportValid(w,h)||!finite(origin)||!finite(s.localPosition)||
       !std::isfinite(o.radius)||o.radius<=0||!std::isfinite(o.maxDistance)||o.maxDistance<=0||
       o.bone<0||o.bone>3||o.priority<0||o.priority>2||!std::isfinite(o.minHealth)||o.minHealth<0||
       (o.prediction&&(!std::isfinite(o.leadMs)||o.leadMs<0))) return {};
    std::optional<Target> best;
    float score=std::numeric_limits<float>::max();
    for (const auto& e:s.entities) {
        if (e.health<=0||e.health<o.minHealth||!std::isfinite(e.health)||(o.teamCheck&&s.localTeam&&e.team==s.localTeam)) continue;
        if (!e.parts[Root].valid) continue;
        float wd=length(e.parts[Root].position-s.localPosition);
        if (!std::isfinite(wd)||wd>o.maxDistance) continue;
        std::array<int,3> choices{Head,Torso,Root};
        std::optional<Target> candidate;
        for (int i=0;i<(o.bone==3?3:1);++i) {
            int bone=o.bone==3?choices[i]:choices[std::clamp(o.bone,0,2)];
            if (!e.parts[bone].valid) continue;
            Vec3 world=e.parts[bone].position;
            if (o.prediction) world=world+e.velocity*(o.leadMs/1000.f);
            auto p=project(s.view,world,w,h);
            if (!p||!onScreen(*p,w,h)) continue;
            float sd=distance(*p,origin);
            if (sd>o.radius) continue;
            if (!candidate||sd<candidate->screenDistance) candidate=Target{e.id,*p,world,sd,wd};
        }
        if (!candidate) continue;
        if (o.sticky&&previous&&candidate->id==previous) return candidate;
        float cs=o.priority==0?candidate->screenDistance:o.priority==1?candidate->worldDistance:e.health;
        if (cs<score) { score=cs; best=candidate; }
    }
    return best;
}
inline Vec2 aimStep(Vec2 target,Vec2 origin,const AimOptions& o,float dt) {
    if(!finite(target)||!finite(origin)||!std::isfinite(dt)||dt<=0||
       !std::isfinite(o.smoothingMs)||o.smoothingMs<0||!std::isfinite(o.maxStep)||o.maxStep<=0||
       o.inputMode<0||o.inputMode>1||(o.inputMode==0&&(!std::isfinite(o.gain)||o.gain<=0))) return {};
    double alpha=o.smoothingMs==0?1.0:-std::expm1(-std::min(double(dt),0.05)*1000.0/o.smoothingMs);
    if(!std::isfinite(o.deadzone)||o.deadzone<0||!std::isfinite(o.maxSpeed)||o.maxSpeed<=0||
       !std::isfinite(o.axisX)||!std::isfinite(o.axisY)||o.axisX<0||o.axisY<0) return {};
    if(std::hypot(double(target.x)-origin.x,double(target.y)-origin.y)<=o.deadzone) return {};
    double gain=o.inputMode==0?o.gain:1.0;
    double x=(double(target.x)-origin.x)*alpha*gain*o.axisX,y=(double(target.y)-origin.y)*alpha*gain*o.axisY;
    double size=std::hypot(x,y);
    if(!std::isfinite(size)) return {};
    double limit=std::min(double(o.maxStep),double(o.maxSpeed)*std::min(double(dt),0.05));
    if(size>limit&&size>0){x*=limit/size;y*=limit/size;}
    return {float(x),float(y)};
}
inline float healthFraction(float hp,float maximum) {
    if(!std::isfinite(hp)||!std::isfinite(maximum)||maximum<=0) return 0;
    return std::clamp(hp/maximum,0.f,1.f);
}
inline bool fresh(const Snapshot& s,Clock::time_point now,float maxAgeMs=180) {
    if(!s.valid||!std::isfinite(maxAgeMs)||maxAgeMs<=0||s.sampled>now) return false;
    return std::chrono::duration<double,std::milli>(now-s.sampled).count()<maxAgeMs;
}
inline bool allowMouseOutput(const Snapshot& s,const AimOptions& options,bool liveMode,
                             bool menuOpen,bool focused,bool rmbHeld,bool hasTarget,Clock::time_point now) {
    return options.enabled&&liveMode&&!s.demo&&s.pid&&s.targetWindow&&!menuOpen&&focused&&rmbHeld&&hasTarget&&fresh(s,now);
}
inline bool validViewMatrix(const Mat4& m) {
    for(float value:m.m) if(!std::isfinite(value)) return false;
    double x=0,y=0,w=0;
    for(int k=0;k<3;++k){x+=std::abs(double(m.m[k]));y+=std::abs(double(m.m[4+k]));}
    for(int k=0;k<4;++k) w+=std::abs(double(m.m[12+k]));
    return x>1e-6&&y>1e-6&&w>1e-6;
}
inline std::optional<Vec2> edgeDirection(const Mat4& mat,Vec3 world) {
    if(!finite(world)) return {};
    auto c=clip(mat,world);
    if(!std::isfinite(c.x)||!std::isfinite(c.y)||!std::isfinite(c.w)) return {};
    double x=c.x,y=-double(c.y),size=std::hypot(x,y);
    if(size<1e-6){if(c.w>=0.01f) return {};return Vec2{0,1};}
    return Vec2{float(x/size),float(y/size)};
}
struct RelativeAccumulator {
    double x=0,y=0;
    void reset(){x=y=0;}
    std::array<int,2> quantize(Vec2 step,float maxStep) {
        if(!finite(step)||!std::isfinite(maxStep)||maxStep<1||maxStep>1000000){reset();return {0,0};}
        if(step.x==0&&step.y==0){reset();return {0,0};}
        double sx=step.x,sy=step.y,size=std::hypot(sx,sy);
        if(size>maxStep){sx*=maxStep/size;sy*=maxStep/size;}
        if(!std::isfinite(x)||!std::isfinite(y)) reset();
        x=std::clamp(x,-1.0,1.0)+sx;y=std::clamp(y,-1.0,1.0)+sy;
        int dx=int(std::round(x)),dy=int(std::round(y));
        while(std::hypot(double(dx),double(dy))>maxStep){
            if(std::abs(dx)>=std::abs(dy)) dx+=dx>0?-1:1;
            else dy+=dy>0?-1:1;
        }
        x=std::clamp(x-dx,-1.0,1.0);y=std::clamp(y-dy,-1.0,1.0);
        return {dx,dy};
    }
};
}
