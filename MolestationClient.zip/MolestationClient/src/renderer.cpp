#include "renderer.hpp"
#include <functional>
#include <cstdio>
#include <limits>

namespace ext {
namespace {
constexpr ImU32 Accent=IM_COL32(151,106,255,255),Text=IM_COL32(222,222,231,255),Muted=IM_COL32(107,107,121,255);
ImVec2 v(Vec2 p){return {p.x,p.y};}
ImU32 color(const std::array<float,4>& c,float alpha=1){return ImGui::ColorConvertFloat4ToU32({c[0],c[1],c[2],c[3]*alpha});}
void text(ImDrawList* d,ImVec2 p,ImU32 c,const std::string& value,float size=14,bool center=false){
    if(center) p.x-=ImGui::GetFont()->CalcTextSizeA(size,10000,0,value.c_str()).x*0.5f;
    d->AddText(ImGui::GetFont(),size,{p.x+1,p.y+1},IM_COL32(0,0,0,210),value.c_str());
    d->AddText(ImGui::GetFont(),size,p,c,value.c_str());
}
void line(ImDrawList* d,ImVec2 a,ImVec2 b,ImU32 c,float thick,bool outline){
    if(outline) d->AddLine(a,b,IM_COL32(0,0,0,220),thick+2);
    d->AddLine(a,b,c,thick);
}
void rect(ImDrawList* d,Bounds b,ImU32 c,float thick,int style,bool outline){
    if(style==0) return;
    if(style==1||style==3){
        if(outline) d->AddRect({b.left,b.top},{b.right,b.bottom},IM_COL32(0,0,0,220),0,0,thick+2);
        d->AddRect({b.left,b.top},{b.right,b.bottom},c,0,0,thick);return;
    }
    float x=(b.right-b.left)*0.22f,y=(b.bottom-b.top)*0.15f;
    for(auto corner:std::array<ImVec2,4>{{{b.left,b.top},{b.right,b.top},{b.left,b.bottom},{b.right,b.bottom}}}){
        float dx=corner.x==b.left?x:-x,dy=corner.y==b.top?y:-y;
        line(d,corner,{corner.x+dx,corner.y},c,thick,outline);line(d,corner,{corner.x,corner.y+dy},c,thick,outline);
    }
}
void box3D(ImDrawList* d,const Entity& e,const Snapshot& s,float w,float h,ImU32 c,const Settings& cfg){
    Vec3 mn{1e20f,1e20f,1e20f},mx{-1e20f,-1e20f,-1e20f};int count=0;
    auto consume=[&](const auto& pieces){for(const auto& p:pieces) if(p.valid) for(auto c:p.corners()){
        mn.x=std::min(mn.x,c.x);mn.y=std::min(mn.y,c.y);mn.z=std::min(mn.z,c.z);
        mx.x=std::max(mx.x,c.x);mx.y=std::max(mx.y,c.y);mx.z=std::max(mx.z,c.z);++count;
    }};
    if(e.geometry.empty()) consume(e.parts);else consume(e.geometry);if(!count) return;
    std::array<std::optional<Vec2>,8> p{};
    for(int k=0;k<8;++k) p[k]=project(s.view,{k&1?mx.x:mn.x,k&2?mx.y:mn.y,k&4?mx.z:mn.z},w,h);
    for(int k=0;k<8;++k) for(int bit:{1,2,4}) if(!(k&bit)&&p[k]&&p[k|bit]) line(d,v(*p[k]),v(*p[k|bit]),c,cfg.thickness,cfg.outline);
}
void healthBar(ImDrawList* d,Bounds b,float hp,float maximum,const Settings& cfg,float extraX=0){
    float ratio=healthFraction(hp,maximum);
    ImU32 c=IM_COL32(int(240*(1-ratio)),int(80+170*ratio),70,255);
    if(cfg.healthPosition==2){
        d->AddRectFilled({b.left-1,b.bottom+5},{b.right+1,b.bottom+11},IM_COL32(0,0,0,220));
        d->AddRectFilled({b.left,b.bottom+6},{b.left+(b.right-b.left)*ratio,b.bottom+10},c);
        if(cfg.healthNumbers&&std::isfinite(hp)){char value[32]{};std::snprintf(value,sizeof value,"%.0f",hp);
            text(d,{b.right+8,b.bottom+1},Text,value,11);}
    }else{
        float x=(cfg.healthPosition==0?b.left-8:b.right+5)+extraX;
        d->AddRectFilled({x-1,b.top-1},{x+4,b.bottom+1},IM_COL32(0,0,0,220));
        d->AddRectFilled({x,b.bottom-(b.bottom-b.top)*ratio},{x+3,b.bottom},c);
        if(cfg.healthNumbers&&std::isfinite(hp)){char value[32]{};std::snprintf(value,sizeof value,"%.0f",hp);
            text(d,{x-2,b.bottom-(b.bottom-b.top)*ratio-16},Text,value,11,true);}
    }
}
bool filter(const Entity& e,const Snapshot& s,const Settings& cfg){
    return e.parts[Root].valid&&(!cfg.deadCheck||e.health>0)&&
        (!cfg.teamCheck||!s.localTeam||e.team!=s.localTeam)&&length(e.parts[Root].position-s.localPosition)<=cfg.maxDistance;
}
void section(const char* value){
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(0.36f,0.36f,0.41f,1));
    ImGui::TextUnformatted(value);ImGui::PopStyleColor();ImGui::Dummy({0,6});
}
void toggleRow(const char* label,bool& value){
    ImGui::PushID(label);auto p=ImGui::GetCursorScreenPos();float w=ImGui::GetContentRegionAvail().x;
    if(ImGui::InvisibleButton("##row",{w,36})) value=!value;
    auto d=ImGui::GetWindowDrawList();bool hovered=ImGui::IsItemHovered();
    d->AddRectFilled(p,{p.x+w,p.y+35},hovered?IM_COL32(29,27,39,255):IM_COL32(19,19,26,255),7);
    d->AddText({p.x+12,p.y+9},Text,label);
    float sx=p.x+w-47,sy=p.y+9;
    d->AddRectFilled({sx,sy},{sx+34,sy+18},value?Accent:IM_COL32(37,37,44,255),9);
    d->AddCircleFilled({sx+(value?25.f:9.f),sy+9},6.2f,value?IM_COL32(255,255,255,255):IM_COL32(137,137,152,255),20);
    ImGui::PopID();
}
void featureRow(const char* label,bool& value,const std::function<void()>& options,ImU32 swatch=IM_COL32(235,235,245,255),bool optionsOnly=false){
    ImGui::PushID(label);auto p=ImGui::GetCursorScreenPos();float w=ImGui::GetContentRegionAvail().x;
    if(ImGui::InvisibleButton("##row",{w,36})){
        if(optionsOnly||ImGui::GetIO().MousePos.x>p.x+w-67) ImGui::OpenPopup("Options");else value=!value;
    }
    auto d=ImGui::GetWindowDrawList();bool hover=ImGui::IsItemHovered();
    d->AddRectFilled(p,{p.x+w,p.y+35},hover?IM_COL32(29,27,39,255):IM_COL32(19,19,26,255),7);
    d->AddText({p.x+12,p.y+9},value?Text:Muted,label);
    auto sc=swatch;if(!value) sc=(swatch&0x00ffffff)|0x55000000;
    d->AddRectFilled({p.x+w-52,p.y+10},{p.x+w-37,p.y+25},sc,4);
    if(value) d->AddCircleFilled({p.x+w-44.5f,p.y+17.5f},2,IM_COL32(0,0,0,110));
    d->AddLine({p.x+w-20,p.y+14},{p.x+w-16,p.y+18},Muted,1.4f);
    d->AddLine({p.x+w-16,p.y+18},{p.x+w-20,p.y+22},Muted,1.4f);
    if(ImGui::BeginPopup("Options")){ImGui::SetNextItemWidth(225);options();ImGui::EndPopup();}
    ImGui::PopID();
}
void selectRow(const char* label,int& value,const char* items){
    ImGui::PushID(label);ImGui::TextUnformatted(label);ImGui::SetNextItemWidth(-1);
    ImGui::Combo("##value",&value,items);ImGui::PopID();
}
void slider(const char* label,float& value,float low,float high,const char* format="%.0f"){
    ImGui::PushID(label);ImGui::TextUnformatted(label);ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat("##slider",&value,low,high,format);ImGui::PopID();
}
void icon(ImDrawList* d,ImVec2 p,int kind,ImU32 c){
    if(kind==0){d->AddCircle({p.x+7,p.y+7},5,c,16,1.5f);d->AddLine({p.x+7,p.y-2},{p.x+7,p.y+16},c);d->AddLine({p.x-2,p.y+7},{p.x+16,p.y+7},c);}
    else if(kind==1){d->AddCircle({p.x+7,p.y+2},3,c,12,1.5f);d->AddLine({p.x+7,p.y+6},{p.x+7,p.y+11},c,1.5f);
        d->AddLine({p.x+2,p.y+10},{p.x+7,p.y+6},c,1.5f);d->AddLine({p.x+12,p.y+10},{p.x+7,p.y+6},c,1.5f);
        d->AddLine({p.x+7,p.y+11},{p.x+3,p.y+16},c,1.5f);d->AddLine({p.x+7,p.y+11},{p.x+11,p.y+16},c,1.5f);}
    else if(kind==2){d->AddCircle({p.x+7,p.y+7},7,c,20,1.3f);d->AddCircle({p.x+7,p.y+7},3,c,16,1);
        d->AddLine({p.x+7,p.y+7},{p.x+12,p.y+1},c,1.3f);}
    else if(kind==3){d->AddRect({p.x+1,p.y+1},{p.x+13,p.y+13},c,2,0,1.5f);d->AddLine({p.x+7,p.y+3},{p.x+7,p.y+11},c);d->AddLine({p.x+3,p.y+7},{p.x+11,p.y+7},c);}
    else if(kind==4){d->AddRect({p.x+1,p.y+2},{p.x+13,p.y+14},c,2,0,1.4f);d->AddLine({p.x+4,p.y+5},{p.x+10,p.y+5},c);d->AddLine({p.x+4,p.y+9},{p.x+10,p.y+9},c);}
    else if(kind==5){for(int k=0;k<3;++k){float y=p.y+2+k*5;d->AddLine({p.x,p.y+2+k*5},{p.x+14,y},c,1.2f);d->AddCircleFilled({p.x+float(k%2?9:4),y},2.4f,c);}}
    else{d->AddRect({p.x,p.y},{p.x+14,p.y+14},c,2,0,1.3f);d->AddLine({p.x+3,p.y+10},{p.x+6,p.y+6},c);d->AddLine({p.x+6,p.y+6},{p.x+9,p.y+8},c);d->AddLine({p.x+9,p.y+8},{p.x+12,p.y+3},c);}
}
void nav(const char* label,int id,int& active){
    auto p=ImGui::GetCursorScreenPos();float w=ImGui::GetContentRegionAvail().x;
    if(ImGui::InvisibleButton(label,{w,36})) active=id;
    auto d=ImGui::GetWindowDrawList();bool selected=active==id;
    if(selected||ImGui::IsItemHovered()) d->AddRectFilled(p,{p.x+w,p.y+35},selected?IM_COL32(29,28,34,255):IM_COL32(20,20,24,255),6);
    icon(d,{p.x+12,p.y+10},id,selected?Accent:Muted);
    d->AddText({p.x+40,p.y+10},selected?Text:Muted,label);
}
void avatar(ImDrawList* d,ImVec2 center,float scale){
    auto point=[&](float x,float y){return ImVec2(center.x+x*scale,center.y+y*scale);};
    d->AddEllipseFilled(point(0,148),{79*scale,12*scale},IM_COL32(0,0,0,180));
    auto block=[&](float x,float y,float w,float h,ImU32 front,ImU32 side,ImU32 top){
        auto a=point(x,y),b=point(x+w,y),c=point(x+w,y+h),e=point(x,y+h);
        float dx=10*scale,dy=-5*scale;
        d->AddQuadFilled(a,b,{b.x+dx,b.y+dy},{a.x+dx,a.y+dy},top);
        d->AddQuadFilled(b,c,{c.x+dx,c.y+dy},{b.x+dx,b.y+dy},side);
        d->AddQuadFilled(a,b,c,e,front);
    };
    block(-39,29,37,109,IM_COL32(44,50,65,255),IM_COL32(25,29,39,255),IM_COL32(75,84,107,255));
    block(2,29,37,109,IM_COL32(49,56,72,255),IM_COL32(28,32,42,255),IM_COL32(78,87,111,255));
    block(-75,-80,32,105,IM_COL32(240,190,148,255),IM_COL32(181,134,98,255),IM_COL32(255,213,174,255));
    block(44,-74,30,99,IM_COL32(246,198,153,255),IM_COL32(179,130,93,255),IM_COL32(255,217,179,255));
    block(-41,-80,83,111,IM_COL32(0,151,217,255),IM_COL32(0,100,168,255),IM_COL32(26,177,235,255));
    d->AddRectFilled(point(-26,-132),point(26,-78),IM_COL32(246,197,150,255),16*scale,ImDrawFlags_RoundCornersTop);
    d->AddEllipseFilled(point(0,-131),{26*scale,9*scale},IM_COL32(255,215,175,255),0,32);
    d->AddRectFilled(point(19,-126),point(26,-81),IM_COL32(192,143,103,150),4*scale);
    d->AddRectFilled(point(-42,-61),point(41,7),IM_COL32(33,77,119,255));
    for(int k=0;k<5;++k){float x=-27+k*11.f;
        d->AddQuadFilled(point(x,-138),point(x+12,-132),point(x+8,-108+(k%2)*9),point(x-3,-118+(k%2)*7),
            k%2?IM_COL32(143,81,38,255):IM_COL32(188,119,54,255));
        d->AddLine(point(x,-135),point(x+6,-112),IM_COL32(231,164,86,255),2.5f*scale);
    }
    d->AddCircleFilled(point(-8,-110),2.2f*scale,IM_COL32(64,48,0,220));
    d->AddCircleFilled(point(8,-110),2.2f*scale,IM_COL32(64,48,0,220));
    d->PathArcTo(point(0,-104),8*scale,0.3f,2.84f,12);d->PathStroke(IM_COL32(91,68,0,210),0,1.5f*scale);
}
void preview(const Settings& cfg,int page,const std::string& inputStatus,const Snapshot& scene,const AvatarView& image){
    section(page==0?"TARGET STUDIO":"AVATAR STUDIO");
    auto pos=ImGui::GetCursorScreenPos();float w=ImGui::GetContentRegionAvail().x;
    auto d=ImGui::GetWindowDrawList();
    float canvas=std::clamp(ImGui::GetContentRegionAvail().y-(page==0?110.f:65.f),180.f,421.f);
    float scale=std::max(.1f,std::min({w/260.f,(canvas-60.f)/310.f,1.08f}));
    ImVec2 c{pos.x+w*0.5f,pos.y+canvas*.5f};
    float artW=230*scale,artH=300*scale;
    d->AddRectFilled({pos.x+3,pos.y+4},{pos.x+w-3,pos.y+canvas-8},IM_COL32(16,16,24,255),14);
    d->AddEllipse({c.x,c.y+145*scale},{95*scale,19*scale},IM_COL32(151,106,255,80),0,64,1);
    if(image.texture){d->AddImage((ImTextureID)(intptr_t)image.texture,{c.x-artW/2,c.y-artH/2},{c.x+artW/2,c.y+artH/2});}
    else avatar(d,c,scale);
    Bounds b{c.x-85*scale,c.y-145*scale,c.x+91*scale,c.y+145*scale};
    if(cfg.esp){
        if(cfg.filled) d->AddRectFilled({b.left,b.top},{b.right,b.bottom},color(cfg.enemy,cfg.fillOpacity));
        rect(d,b,color(cfg.enemy),cfg.thickness,cfg.boxStyle,cfg.outline);
        if(cfg.boxStyle==3){
            Bounds back{b.left+12,b.top-8,b.right+12,b.bottom-8};
            rect(d,back,color(cfg.enemy),cfg.thickness,1,cfg.outline);
            for(auto point:std::array<ImVec2,4>{{{b.left,b.top},{b.right,b.top},{b.left,b.bottom},{b.right,b.bottom}}})
                line(d,point,{point.x+12,point.y-8},color(cfg.enemy),cfg.thickness,cfg.outline);
        }
        if(cfg.names) text(d,{(b.left+b.right)/2,b.top-24},color(cfg.enemy),scene.localName.empty()?"Bacon Hair":scene.localName,cfg.textSize,true);
        if(cfg.health) healthBar(d,b,85,100,cfg);
        if(cfg.distances) text(d,{(b.left+b.right)/2,b.bottom+16},color(cfg.enemy),"24 studs",cfg.textSize,true);
        if(cfg.teamLabels) text(d,{(b.left+b.right)/2,b.top-42},color(cfg.enemy),"Red team",cfg.textSize-1,true);
        if(cfg.skeleton){
            const Vec2 nodes[]{{0,-104},{0,-36},{0,23},{-59,-52},{-61,-9},{-61,27},{58,-52},{60,-9},{60,27},
                {-20,49},{-20,90},{-20,137},{21,49},{21,90},{21,137},{0,23}};
            for(auto segment:Skeleton){auto a=nodes[segment[0]],z=nodes[segment[1]];
                line(d,{c.x+a.x*scale,c.y+a.y*scale},{c.x+z.x*scale,c.y+z.y*scale},color(cfg.enemy),cfg.thickness,cfg.outline);}
        }
        if(cfg.headCircle) d->AddCircle({c.x,c.y-106*scale},30*scale,color(cfg.enemy),48,cfg.thickness);
        if(cfg.snaplines) line(d,{c.x,pos.y+canvas-22},{c.x,c.y+23*scale},color(cfg.enemy),cfg.thickness,cfg.outline);
    }
    if(page==0){
        if(cfg.fovCircle) d->AddCircle({c.x,c.y-30},std::clamp(cfg.aim.radius*0.65f,10.f,std::max(10.f,std::min(w,canvas)*0.47f)),IM_COL32(148,105,255,160),80,1.1f);
        d->AddCircle({c.x,c.y-106*scale},5,Accent,20,2);d->AddCircleFilled({c.x,c.y-106*scale},2,Accent);
    }
    ImGui::Dummy({w,canvas});
    ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(0.4f,0.4f,0.46f,1));
    ImGui::TextWrapped(image.texture?"Your public avatar thumbnail. ESP framing here is illustrative.":"Bacon-hair fallback. Live ESP still uses the actual player rig.");ImGui::PopStyleColor();
    if(page==0){ImGui::Spacing();section("INPUT STATE");ImGui::TextWrapped("%s",inputStatus.c_str());}
}
}
void setTheme(){
    auto& s=ImGui::GetStyle();s.WindowRounding=14;s.ChildRounding=10;s.FrameRounding=7;s.PopupRounding=10;
    s.WindowBorderSize=1;s.ChildBorderSize=0;s.FrameBorderSize=0;s.WindowPadding={0,0};
    s.FramePadding={10,7};s.ItemSpacing={4,3};s.ScrollbarSize=7;s.GrabMinSize=8;
    auto* c=s.Colors;
    c[ImGuiCol_Text]={0.87f,0.87f,0.91f,1};c[ImGuiCol_TextDisabled]={0.4f,0.4f,0.46f,1};
    c[ImGuiCol_WindowBg]={0.035f,0.035f,0.044f,1};c[ImGuiCol_ChildBg]={0.035f,0.035f,0.044f,1};
    c[ImGuiCol_PopupBg]={0.06f,0.06f,0.076f,1};c[ImGuiCol_Border]={0.16f,0.145f,0.23f,1};
    c[ImGuiCol_FrameBg]={0.07f,0.07f,0.086f,1};c[ImGuiCol_FrameBgHovered]={0.12f,0.11f,0.15f,1};
    c[ImGuiCol_FrameBgActive]={0.17f,0.12f,0.23f,1};c[ImGuiCol_CheckMark]={0.55f,0.30f,1,1};
    c[ImGuiCol_SliderGrab]={0.47f,0.24f,1,1};c[ImGuiCol_SliderGrabActive]={0.65f,0.42f,1,1};
    c[ImGuiCol_Button]={0.11f,0.10f,0.14f,1};c[ImGuiCol_ButtonHovered]={0.23f,0.14f,0.38f,1};
    c[ImGuiCol_ButtonActive]={0.33f,0.20f,0.52f,1};c[ImGuiCol_Header]={0.20f,0.12f,0.32f,1};
    c[ImGuiCol_HeaderHovered]={0.25f,0.16f,0.39f,1};c[ImGuiCol_HeaderActive]={0.32f,0.20f,0.5f,1};
    c[ImGuiCol_Separator]={0.09f,0.09f,0.11f,1};c[ImGuiCol_ScrollbarBg]={0,0,0,0};
    c[ImGuiCol_ScrollbarGrab]={0.16f,0.15f,0.19f,1};c[ImGuiCol_TitleBg]=c[ImGuiCol_WindowBg];
}
void drawOverlay(const Snapshot& s,const Settings& cfg,float w,float h,Vec2 cursor,
                 const std::optional<Target>& target,bool holding,float fps){
    auto d=ImGui::GetBackgroundDrawList();Vec2 origin=cfg.aim.origin==0?Vec2{w/2,h/2}:cursor;
    if(cfg.fovCircle&&cfg.aim.enabled) d->AddCircle(v(origin),cfg.aim.radius,IM_COL32(156,119,255,155),96,1);
    if(cfg.crosshair){d->AddLine({w/2-6,h/2},{w/2+6,h/2},Text,1);d->AddLine({w/2,h/2-6},{w/2,h/2+6},Text,1);}
    if(cfg.watermark||s.demo){
        char f[64]{};std::snprintf(f,sizeof f,"  |  %.0f FPS",fps);
        std::string label="MC  /  "+std::string(s.demo?"DEMO - NO MOUSE OUTPUT":s.valid?"LIVE":"DISCONNECTED")+f+" // "+s.localName;
        auto sz=ImGui::CalcTextSize(label.c_str());d->AddRectFilled({14,14},{sz.x+38,45},IM_COL32(13,12,17,225),5);
        d->AddRectFilled({14,14},{17,45},Accent,2);text(d,{25,22},Text,label,14);
    }
    if(!s.valid){text(d,{24,55},Muted,"Insert: menu  |  End: exit",13);return;}
    // Molestation Client: username lock — top right badge, always on overlay
    if(!s.localName.empty()){
        std::string lockLabel="MC // "+s.localName;
        auto sz2=ImGui::CalcTextSize(lockLabel.c_str());
        d->AddRectFilled({w-sz2.x-30,14},{w-10,43},IM_COL32(13,12,17,220),5);
        d->AddRectFilled({w-sz2.x-30,14},{w-sz2.x-27,43},IM_COL32(200,40,40,255),2);
        text(d,{w-sz2.x-18,22},IM_COL32(255,90,90,255),lockLabel,14);
    }
    if(cfg.esp) for(const auto& e:s.entities){
        if(!filter(e,s,cfg)) continue;
        auto c=color(target&&e.id==target->id?cfg.selected:(s.localTeam&&e.team==s.localTeam?cfg.friendly:cfg.enemy));
        auto b=bounds(e,s.view,w,h);
        if(!b){
            if(cfg.offscreen){auto direction=edgeDirection(s.view,e.parts[Root].position);
                if(!direction||w<60||h<60) continue;
                float dx=direction->x,dy=direction->y;
                float k=std::min((w/2-28)/std::max(std::abs(dx),0.001f),(h/2-28)/std::max(std::abs(dy),0.001f));
                ImVec2 tip{w/2+dx*k,h/2+dy*k};
                d->AddTriangleFilled(tip,{tip.x-dx*13-dy*6,tip.y-dy*13+dx*6},
                    {tip.x-dx*13+dy*6,tip.y-dy*13-dx*6},c);
            }
            continue;
        }
        Bounds bOff{b->left+cfg.boxOffsetX,b->top+cfg.boxOffsetY,b->right+cfg.boxOffsetX,b->bottom+cfg.boxOffsetY};
        if(cfg.filled) d->AddRectFilled({bOff.left,bOff.top},{bOff.right,bOff.bottom},color(s.localTeam&&e.team==s.localTeam?cfg.friendly:cfg.enemy,cfg.fillOpacity));
        if(cfg.boxStyle==3) box3D(d,e,s,w,h,c,cfg);else rect(d,bOff,c,cfg.thickness,cfg.boxStyle,cfg.outline);
        if(cfg.skeleton) for(auto segment:Skeleton){
            if(!e.parts[segment[0]].valid||!e.parts[segment[1]].valid) continue;
            auto a=project(s.view,e.parts[segment[0]].position,w,h),z=project(s.view,e.parts[segment[1]].position,w,h);
            if(a&&z) line(d,v(*a),v(*z),c,cfg.thickness,cfg.outline);
        }
        if(cfg.health) healthBar(d,*b,e.health,e.maxHealth,cfg);
        float middle=(b->left+b->right)/2;
        if(cfg.names) text(d,{middle,b->top-cfg.textSize-5+cfg.nameOffsetY},c,e.name,cfg.textSize,true);
        if(cfg.teamLabels&&!e.teamName.empty()) text(d,{middle,b->top-cfg.textSize*2-7},c,e.teamName,cfg.textSize-1,true);
        if(cfg.distances){char dist[64]{};std::snprintf(dist,sizeof dist,"%.0f studs",length(e.parts[Root].position-s.localPosition));
            text(d,{middle,b->bottom+(cfg.health&&cfg.healthPosition==2?14.f:4.f)+cfg.distOffsetY},c,dist,cfg.textSize,true);}
        if(cfg.headCircle&&e.parts[Head].valid){
            auto head=project(s.view,e.parts[Head].position,w,h),edge=project(s.view,e.parts[Head].position+Vec3{0,e.parts[Head].size.y*.65f,0},w,h);
            if(head&&edge) d->AddCircle(v(*head),std::clamp(distance(*head,*edge),2.f,100.f),c,32,cfg.thickness);
        }
        if(cfg.snaplines){auto p=project(s.view,e.parts[Root].position,w,h);if(p){
            Vec2 from=cfg.snapOrigin==0?Vec2{w/2,h-1}:cfg.snapOrigin==1?Vec2{w/2,h/2}:cursor;
            line(d,v(from),v(*p),c,cfg.thickness,cfg.outline);}}
    }
    if(cfg.radar&&w>=180&&h>=180){
        auto& style=cfg.radarStyle;float diameter=std::min(style.size,std::min(w,h)-48),radius=diameter/2;
        bool right=style.corner%2==1,bottom=style.corner>=2,square=style.shape==1;
        ImVec2 center{right?w-radius-20:radius+20,bottom?h-radius-44:radius+50};
        auto panel=IM_COL32(16,15,25,int(255*style.opacity));auto border=IM_COL32(136,105,195,155);
        if(square){d->AddRectFilled({center.x-radius-6,center.y-radius-6},{center.x+radius+6,center.y+radius+6},panel,12);d->AddRect({center.x-radius,center.y-radius},{center.x+radius,center.y+radius},border,9);}
        else {d->AddCircleFilled(center,radius+6,panel,64);d->AddCircle(center,radius,border,64,1.2f);}
        if(style.rings) for(float fraction:{.33f,.66f}){
            float r=radius*fraction;if(square) d->AddRect({center.x-r,center.y-r},{center.x+r,center.y+r},IM_COL32(128,102,170,45),5);
            else d->AddCircle(center,r,IM_COL32(128,102,170,45),48);}
        d->AddLine({center.x-radius,center.y},{center.x+radius,center.y},IM_COL32(137,112,179,65));
        d->AddLine({center.x,center.y-radius},{center.x,center.y+radius},IM_COL32(137,112,179,65));
        text(d,{center.x,center.y-radius-21},Text,style.orientation?"CAMERA UP":"NORTH UP",10,true);
        d->AddTriangleFilled({center.x,center.y-6},{center.x-4,center.y+4},{center.x+4,center.y+4},Accent);
        for(const auto& e:s.entities) if(filter(e,s,cfg)){
            auto point=radarPoint(e.parts[Root].position,s.localPosition,cfg.radarRange,radius-8,s.cameraYaw,style.orientation!=0,square,style.edgeMarkers);
            if(!point) continue;
            ImVec2 at{center.x+point->offset.x,center.y+point->offset.y};
            auto c=color(target&&target->id==e.id?cfg.selected:s.localTeam&&e.team==s.localTeam?cfg.friendly:cfg.enemy);
            if(point->edge){float angle=std::atan2(point->offset.y,point->offset.x),x=std::cos(angle),y=std::sin(angle);
                d->AddTriangleFilled({at.x+x*4,at.y+y*4},{at.x-x*3-y*3,at.y-y*3+x*3},{at.x-x*3+y*3,at.y-y*3-x*3},c);}
            else d->AddCircleFilled(at,style.dotSize,c,16);
            if(style.altitude&&std::abs(point->altitude)>12){float direction=point->altitude>0?-1.f:1.f;
                d->AddLine({at.x-2,at.y+direction*7},{at.x,at.y+direction*9},c);d->AddLine({at.x,at.y+direction*9},{at.x+2,at.y+direction*7},c);}
            if(style.labels&&!point->edge) text(d,{at.x+7,at.y-5},c,e.name,10);
        }
        char range[48]{};std::snprintf(range,sizeof range,"%.0f studs",cfg.radarRange);text(d,{center.x,center.y+radius+9},Muted,range,10,true);
    }
    if(cfg.accountFooter&&!s.localName.empty()){
        std::string label=s.localName+(s.demo?"  /  DEMO":"  /  LOCAL ACCOUNT");auto size=ImGui::CalcTextSize(label.c_str());
        d->AddRectFilled({18,h-39},{size.x+42,h-12},IM_COL32(16,15,24,225),7);text(d,{29,h-33},Text,label,12);
    }
    if(target&&holding&&cfg.targetLine){
        d->AddLine(v(origin),v(target->screen),color(cfg.selected,.6f),1);
        d->AddCircle(v(target->screen),5,color(cfg.selected),24,1.8f);
    }
}
void drawMenu(Settings& cfg,Provider& provider,const Snapshot& s,const std::filesystem::path& folder,
              const std::string& inputStatus,const std::string& recoilStatus,const AvatarView& image,bool& running){
    cfg.clamp();
    static int page=1;static std::string notice;static float noticeUntil=0;
    auto toast=[&](const std::string& message){notice=message;noticeUntil=float(ImGui::GetTime())+4;};
    auto display=ImGui::GetIO().DisplaySize;ImVec2 size=menuSize(display);
    ImGui::SetNextWindowSize(size,ImGuiCond_Always);
    ImGui::SetNextWindowPos({(display.x-size.x)/2,(display.y-size.y)/2},ImGuiCond_Always);
    ImGui::Begin("Molestation Client",nullptr,ImGuiWindowFlags_NoTitleBar|ImGuiWindowFlags_NoResize|ImGuiWindowFlags_NoCollapse|ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoMove);
    if(size.x<480||size.y<320){
        ImGui::SetCursorPos({12,12});ImGui::TextWrapped("Display too small for the full menu. Increase desktop resolution.");
        ImGui::SetCursorPosX(12);if(ImGui::Button("Exit")) running=false;
        ImGui::End();return;
    }
    auto root=ImGui::GetWindowPos();auto d=ImGui::GetWindowDrawList();float sidebar=190,bodyWidth=size.x-sidebar;
    d->AddRectFilled(root,{root.x+sidebar,root.y+size.y},IM_COL32(17,17,25,255),14,ImDrawFlags_RoundCornersLeft);
    d->AddLine({root.x+sidebar,root.y+1},{root.x+sidebar,root.y+size.y-1},IM_COL32(25,24,31,255));
    d->AddText(ImGui::GetFont(),16,{root.x+14,root.y+19},Text,"Molestation Client");d->AddRectFilled({root.x+96,root.y+24},{root.x+160,root.y+41},IM_COL32(180,20,20,200),4);
    d->AddText(ImGui::GetFont(),10,{root.x+102,root.y+27},IM_COL32(255,80,80,255),"FREE");
    ImGui::SetCursorPos({12,82});ImGui::BeginChild("Navigation",{sidebar-24,size.y-171},false);
    ImGui::SetCursorPosX(10);section("COMBAT");nav("Aimbot",0,page);nav("Recoil",7,page);ImGui::Dummy({0,18});
    ImGui::SetCursorPosX(10);section("VISUALS");nav("Players",1,page);nav("Radar",2,page);nav("Extras",3,page);ImGui::Dummy({0,18});
    ImGui::SetCursorPosX(10);section("SYSTEM");nav("Profiles",4,page);nav("Options",5,page);nav("Diagnostics",6,page);ImGui::EndChild();
    d->AddLine({root.x+20,root.y+size.y-83},{root.x+sidebar-20,root.y+size.y-83},IM_COL32(27,26,33,255));
    std::string account=s.localName.empty()?"Waiting for account":s.localName;
    std::string shown=account;
    while(!shown.empty()&&ImGui::CalcTextSize(shown.c_str()).x>sidebar-50) shown.pop_back();
    if(shown!=account) shown+="...";
    d->AddText({root.x+24,root.y+size.y-60},Text,shown.c_str());
    d->AddText(ImGui::GetFont(),11,{root.x+24,root.y+size.y-37},Muted,s.demo?"DEMO / NO OUTPUT":s.localName.empty()?"LIVE ACCOUNT NOT READ YET":"DETECTED LOCAL ACCOUNT");
    ImGui::SetCursorPos({sidebar+22,14});
    if(ImGui::Button("Configuration   v",{170,33})) ImGui::OpenPopup("ConfigActions");
    if(ImGui::BeginPopup("ConfigActions")){
        if(ImGui::MenuItem("Save settings")) toast(cfg.save(folder/"settings.ini")?"Settings saved":"Could not save settings");
        if(ImGui::MenuItem("Load settings")) toast(cfg.load(folder/"settings.ini")?"Settings loaded":"No saved settings found");
        if(ImGui::MenuItem("Reset defaults")){cfg=Settings{};toast("Defaults restored");}
        ImGui::EndPopup();
    }
    std::string badge=s.demo?"DEMO":s.valid?"LIVE":"OFFLINE";
    d->AddCircleFilled({root.x+size.x-135,root.y+31},3,s.valid&&!s.demo?IM_COL32(109,228,156,255):IM_COL32(173,128,255,255));
    d->AddText(ImGui::GetFont(),11,{root.x+size.x-123,root.y+24},Muted,badge.c_str());
    ImGui::SetCursorPos({size.x-44,16});if(ImGui::Button("x",{26,28})) running=false;
    d->AddLine({root.x+sidebar,root.y+61},{root.x+size.x,root.y+61},IM_COL32(23,22,29,255));
    const float height=size.y-105;
    ImGui::SetCursorPos({sidebar+21,80});
    if(page<=1){
        float controlsWidth=std::min(356.f,(bodyWidth-54)*0.51f);
        ImGui::BeginChild("Controls",{controlsWidth,height},false);
        if(page==1){
            section("ENEMY");toggleRow("Enabled",cfg.esp);toggleRow("Team check",cfg.teamCheck);
            bool filters=cfg.deadCheck,oldFilter=filters;featureRow("Filters",filters,[&]{ImGui::Checkbox("Exclude dead players",&cfg.deadCheck);
                slider("Maximum distance",cfg.maxDistance,10,10000,"%.0f studs");},IM_COL32(150,150,170,255));if(filters!=oldFilter) cfg.deadCheck=filters;
            ImGui::Dummy({0,15});section("ENEMY MODEL");
            bool box=cfg.boxStyle!=0,old=box;
            featureRow("Box",box,[&]{selectRow("Style",cfg.boxStyle,"None\0Full 2D\0Corner 2D\0World AABB 3D\0");
                slider("Line width",cfg.thickness,1,4,"%.1f px");ImGui::Checkbox("Black outline",&cfg.outline);},color(cfg.enemy));
            if(old!=box) cfg.boxStyle=box?2:0;
            featureRow("Name",cfg.names,[&]{slider("Font size",cfg.textSize,10,22,"%.0f px");
                ImGui::Checkbox("Distance label",&cfg.distances);ImGui::Checkbox("Team label",&cfg.teamLabels);},color(cfg.enemy));
            featureRow("Health",cfg.health,[&]{ImGui::Checkbox("Health numbers",&cfg.healthNumbers);
                selectRow("Bar position",cfg.healthPosition,"Left\0Right\0Bottom\0");},IM_COL32(91,241,94,255));
            featureRow("Skeleton",cfg.skeleton,[&]{ImGui::TextWrapped("R15 part-center connections; R6 has synthesized limb joints.");
                slider("Line width",cfg.thickness,1,4,"%.1f px");},color(cfg.enemy));
            featureRow("Tracer",cfg.snaplines,[&]{selectRow("Origin",cfg.snapOrigin,"Bottom center\0Screen center\0Mouse cursor\0");},color(cfg.enemy));
            ImGui::Dummy({0,10});section("ESP ELEMENT OFFSETS");
            ImGui::TextUnformatted("Box offset X");ImGui::SetNextItemWidth(-1);ImGui::SliderFloat("##boxox",&cfg.boxOffsetX,-100,100,"%.0f px");
            ImGui::TextUnformatted("Box offset Y");ImGui::SetNextItemWidth(-1);ImGui::SliderFloat("##boxoy",&cfg.boxOffsetY,-100,100,"%.0f px");
            ImGui::TextUnformatted("Name offset Y");ImGui::SetNextItemWidth(-1);ImGui::SliderFloat("##namoy",&cfg.nameOffsetY,-40,10,"%.0f px");
            ImGui::TextUnformatted("Distance offset Y");ImGui::SetNextItemWidth(-1);ImGui::SliderFloat("##distoy",&cfg.distOffsetY,-10,30,"%.0f px");
            ImGui::TextUnformatted("Health bar side offset");ImGui::SetNextItemWidth(-1);ImGui::SliderFloat("##hpox",&cfg.healthBarOffsetX,-20,20,"%.0f px");
            ImGui::Dummy({0,10});featureRow("Head circle",cfg.headCircle,[&]{ImGui::TextWrapped("Radius follows the projected head size.");}color(cfg.enemy));
            featureRow("Fill",cfg.filled,[&]{slider("Opacity",cfg.fillOpacity,0,.4f,"%.2f");},color(cfg.enemy));
            featureRow("Off-screen",cfg.offscreen,[&]{ImGui::TextWrapped("Edge arrows show players outside the viewport, including behind the camera.");},color(cfg.enemy));
            bool colors=true;featureRow("Colors",colors,[&]{ImGui::ColorEdit4("Enemies",cfg.enemy.data());
                ImGui::ColorEdit4("Teammates",cfg.friendly.data());ImGui::ColorEdit4("Selected target",cfg.selected.data());},color(cfg.enemy),true);
        }else{
            section("AIMBOT");toggleRow("Enabled",cfg.aim.enabled);toggleRow("Team check",cfg.aim.teamCheck);toggleRow("Sticky target",cfg.aim.sticky);
            ImGui::Dummy({0,12});section("TARGETING");
            selectRow("Target part",cfg.aim.bone,"Head\0Torso\0Root\0Adaptive / nearest\0");
            selectRow("Priority",cfg.aim.priority,"Closest to FOV center\0Closest in world\0Lowest health\0");
            selectRow("Activation",cfg.aim.activation,"Right mouse\0Left mouse\0Alt\0Mouse 4\0");
            slider("FOV radius",cfg.aim.radius,20,650,"%.0f px");slider("Smoothing",cfg.aim.smoothingMs,0,300,"%.0f ms");
            slider("Maximum range",cfg.aim.maxDistance,10,10000,"%.0f studs");
            bool advanced=cfg.aim.prediction;featureRow("Prediction",advanced,[&]{slider("Linear lead time",cfg.aim.leadMs,0,250,"%.0f ms");
                ImGui::TextWrapped("Velocity extrapolation, not ballistic prediction.");},Accent);cfg.aim.prediction=advanced;
            selectRow("Mouse output",cfg.aim.inputMode,"Relative / camera\0Absolute / cursor\0");
            selectRow("FOV origin",cfg.aim.origin,"Screen center\0Mouse cursor\0");
            ImGui::Dummy({0,10});section("PRECISION & LIMITS");
            slider("Deadzone",cfg.aim.deadzone,0,20,"%.1f px");slider("Movement speed limit",cfg.aim.maxSpeed,50,5000,"%.0f units/s");
            slider("Target acquisition delay",cfg.aim.switchDelayMs,0,500,"%.0f ms");slider("Minimum target health",cfg.aim.minHealth,0,200,"%.0f HP");
            slider("Horizontal scale",cfg.aim.axisX,0,2,"%.2f x");slider("Vertical scale",cfg.aim.axisY,0,2,"%.2f x");
            slider("Relative sensitivity",cfg.aim.gain,.05f,4,"%.2f x");slider("Maximum step",cfg.aim.maxStep,1,100,"%.0f units");
        }
        ImGui::EndChild();ImGui::SameLine(0,21);ImGui::BeginChild("PlayerPreview",{0,height},false);
        cfg.clamp();preview(cfg,page,inputStatus,s,image);ImGui::EndChild();
    }else{
        ImGui::BeginChild("FullPanel",{bodyWidth-42,height},false);
        if(page==2){
            section("TACTICAL RADAR");toggleRow("Enabled",cfg.radar);slider("World range",cfg.radarRange,25,2000,"%.0f studs");
            selectRow("Shape",cfg.radarStyle.shape,"Circle\0Square\0");selectRow("Orientation",cfg.radarStyle.orientation,"North up\0Camera up\0");
            selectRow("Placement",cfg.radarStyle.corner,"Top left\0Top right\0Bottom left\0Bottom right\0");
            slider("Size",cfg.radarStyle.size,140,340,"%.0f px");slider("Background opacity",cfg.radarStyle.opacity,.2f,1,"%.2f");slider("Marker size",cfg.radarStyle.dotSize,2,8,"%.1f px");
            toggleRow("Range rings",cfg.radarStyle.rings);toggleRow("Out-of-range edge markers",cfg.radarStyle.edgeMarkers);toggleRow("Player labels",cfg.radarStyle.labels);toggleRow("Height indicators",cfg.radarStyle.altitude);
            ImGui::TextWrapped("Local position is the center triangle; the selected player is purple. Height arrows show players above or below you. Radar shares visual filters.");
        }else if(page==7){
            section("RECOIL COMPENSATION");toggleRow("Enabled",cfg.recoil.enabled);
            selectRow("Method",cfg.recoil.mode,"Steady compensation\0Custom pattern / advanced\0");
            ImGui::TextWrapped("Mouse compensation only. It does not remove random weapon spread or modify game recoil. Hold RMB + LMB. Disabled in Demo, menus and unfocused/stale sessions.");
            if(cfg.recoil.mode==0){slider("Horizontal rate",cfg.recoil.horizontal,-300,300,"%.0f units/s");slider("Vertical rate",cfg.recoil.vertical,-300,300,"%.0f units/s");}
            else {
                static char buffer[1025]{};if(std::string(buffer)!=cfg.recoil.pattern&&!ImGui::IsAnyItemActive()) std::snprintf(buffer,sizeof buffer,"%s",cfg.recoil.pattern.c_str());
                ImGui::TextWrapped("Pattern format: duration_ms,x_rate,y_rate;...  Up to 16 segments. This is data, NOT executable Lua or code. Advanced mode is not recommended without calibration.");
                ImGui::SetNextItemWidth(-1);ImGui::InputTextMultiline("##pattern",buffer,sizeof buffer,{0,90});
                if(ImGui::Button("Apply valid pattern")){if(parsePattern(buffer)){cfg.recoil.pattern=buffer;toast("Pattern applied");}else toast("Invalid pattern; previous pattern preserved");}
            }
            slider("Start delay",cfg.recoil.delayMs,0,500,"%.0f ms");slider("Maximum step",cfg.recoil.maxStep,1,100,"%.0f units");
            ImGui::Dummy({0,18});section("INPUT STATE");ImGui::TextWrapped("%s",recoilStatus.c_str());
            ImGui::TextWrapped("Aim + recoil are combined into one bounded relative command. When enabled together, use relative aim mode.");
        }else if(page==3){
            section("OVERLAY");toggleRow("Crosshair",cfg.crosshair);toggleRow("FOV circle",cfg.fovCircle);
            toggleRow("Target line",cfg.targetLine);toggleRow("Watermark",cfg.watermark);toggleRow("Distance labels",cfg.distances);toggleRow("Team labels",cfg.teamLabels);
            ImGui::Dummy({0,20});section("FILTERS");toggleRow("ESP team check",cfg.teamCheck);toggleRow("Exclude dead players",cfg.deadCheck);
            slider("ESP draw distance",cfg.maxDistance,10,10000,"%.0f studs");
            ImGui::Spacing();ImGui::TextDisabled("No fabricated visibility, chams, silent aim or game-state writes.");
        }else if(page==4){
            section("DATA SOURCE");int mode=int(provider.mode());
            if(ImGui::RadioButton("Live Roblox / native read-only reader",mode==0)) provider.mode(Provider::Live);
            if(ImGui::RadioButton("Demo / simulated data, mouse output disabled",mode==1)) provider.mode(Provider::Demo);
            ImGui::Dummy({0,16});section("SETTINGS");
            if(ImGui::Button("Save local config",{180,34})) toast(cfg.save(folder/"settings.ini")?"Settings saved":"Could not save settings");
            ImGui::SameLine();if(ImGui::Button("Load local config",{180,34})) toast(cfg.load(folder/"settings.ini")?"Settings loaded":"No saved settings found");
            ImGui::Dummy({0,12});
            for(int i=1;i<=3;++i){
                ImGui::PushID(i);ImGui::Text("Slot %d",i);ImGui::SameLine(105);
                auto path=folder/("preset-"+std::to_string(i)+".ini");
                if(ImGui::Button("Save",{105,30})) toast(cfg.save(path)?"Preset saved":"Could not save preset");
                ImGui::SameLine();
                if(ImGui::Button("Load",{105,30})) toast(cfg.load(path)?"Preset loaded":"Preset is empty");
                ImGui::PopID();
            }
            ImGui::Dummy({0,16});section("QUICK PRESETS");
            if(ImGui::Button("Minimal ESP",{160,34})){cfg.esp=true;cfg.names=cfg.health=true;cfg.skeleton=cfg.snaplines=cfg.filled=cfg.headCircle=false;cfg.boxStyle=2;toast("Minimal ESP applied");}
            ImGui::SameLine();if(ImGui::Button("Smooth aim",{160,34})){cfg.aim.smoothingMs=150;cfg.aim.radius=130;cfg.aim.maxStep=15;cfg.aim.sticky=true;toast("Smooth settings applied; enable aim separately");}
            ImGui::SameLine();if(ImGui::Button("Defaults",{130,34})){cfg=Settings{};toast("Defaults restored");}
        }else if(page==5){
            section("MOLESTATION CLIENT // DISPLAY");
            ImGui::TextUnformatted("Monitor Hz (ESP frame pacing)");ImGui::SetNextItemWidth(320);ImGui::SliderInt("##mhz",&cfg.monitorHz,30,360,"%d Hz");
            ImGui::TextWrapped("Set this to your actual monitor refresh rate. ESP draw interval is derived from this.");
            ImGui::Dummy({0,12});section("PERFORMANCE");toggleRow("VSync",cfg.vsync);ImGui::TextUnformatted("Frame cap (when VSync is off)");
            ImGui::SetNextItemWidth(320);ImGui::SliderInt("##fps",&cfg.frameCap,30,300,"%d FPS");
            ImGui::TextUnformatted("Background render cap");ImGui::SetNextItemWidth(320);ImGui::SliderInt("##idle",&cfg.idleFps,10,60,"%d FPS");
            ImGui::TextUnformatted("Reader sampling");ImGui::SetNextItemWidth(320);ImGui::SliderInt("##hz",&cfg.readerHz,10,60,"%d Hz");
            ImGui::TextUnformatted("Entity discovery interval");ImGui::SetNextItemWidth(320);ImGui::SliderInt("##cache",&cfg.cacheMs,250,2500,"%d ms");
            ImGui::Text("Last reader work: %.2f ms",provider.sampleCostMs());
            ImGui::Dummy({0,12});section("ACCOUNT & AVATAR");toggleRow("Public avatar thumbnail",cfg.onlineAvatar);toggleRow("Overlay account footer",cfg.accountFooter);
            ImGui::TextWrapped("%s",image.status.c_str());ImGui::TextWrapped("Optional HTTPS lookup sends only your public user ID to Roblox thumbnails/CDN. No login, cookies or password. Turn off for offline fallback.");
            ImGui::Dummy({0,20});section("CONTROLS");
            ImGui::TextUnformatted("Insert    Show / hide menu");ImGui::TextUnformatted("End       Exit application");
            ImGui::TextUnformatted("Aim key   Configurable in Aimbot; default RMB");
            ImGui::Dummy({0,20});section("READER");
            if(ImGui::Button("Reload offset profile",{230,34})){provider.reload();toast("Reader reset; profile reloaded");}
            ImGui::TextWrapped("Edit profiles/roblox.ini only for the exact detected client build. A version mismatch disables entity reads and mouse output.");
            ImGui::Dummy({0,16});ImGui::TextWrapped("External read-only renderer: no injected DLL, driver, elevation request or updater. Optional public-avatar HTTPS is separate from game reads.");
            ImGui::TextWrapped("Synthetic input may be ignored by a game. Cursor mode is not equivalent to changing a locked camera.");
        }else{
            section("CONNECTION");ImGui::TextWrapped("%s",s.status.c_str());ImGui::Spacing();
            ImGui::TextWrapped("Account: %s",s.localName.empty()?"Not read":s.localName.c_str());ImGui::Text("Public user ID: %llu",static_cast<unsigned long long>(s.localUserId));
            ImGui::Text("Process ID: %u",s.pid);ImGui::TextWrapped("Client: %s",s.version.empty()?"Not detected":s.version.c_str());
            ImGui::Text("Validated entities: %zu",s.entities.size());
            ImGui::Text("Data revision: %llu",static_cast<unsigned long long>(s.revision));
            ImGui::Text("Data age: %.0f ms",std::chrono::duration<float,std::milli>(Clock::now()-s.sampled).count());
            ImGui::Dummy({0,20});section("MOUSE OUTPUT");ImGui::TextWrapped("Aim: %s",inputStatus.c_str());ImGui::TextWrapped("Recoil: %s",recoilStatus.c_str());
            ImGui::Dummy({0,20});section("BUILD STATUS");
            ImGui::TextWrapped("Windows x64 binary. The live Roblox reader and this public offset profile have NOT been runtime-verified against a current Windows Roblox session.");
            ImGui::TextWrapped("A matching version is necessary, not proof that the offsets are correct. Invalid reads fail closed.");
            ImGui::Spacing();if(ImGui::Button("Retry / reload profile",{230,34})) provider.reload();
        }
        ImGui::EndChild();
    }
    d->AddLine({root.x+sidebar,root.y+size.y-32},{root.x+size.x,root.y+size.y-32},IM_COL32(25,23,31,255));
    std::string footer=float(ImGui::GetTime())<noticeUntil?notice:"INSERT  Menu      END  Exit      Aim key: Aimbot settings";
    d->AddText(ImGui::GetFont(),11,{root.x+sidebar+22,root.y+size.y-23},Muted,footer.c_str());
    cfg.clamp();ImGui::End();
}
}
