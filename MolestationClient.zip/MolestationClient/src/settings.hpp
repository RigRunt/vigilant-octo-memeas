#pragma once
#include "core.hpp"
#include "features.hpp"
#include <atomic>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <locale>
#include <map>
#include <sstream>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif

namespace ext {
class Ini {
    std::map<std::string,std::string> data_;
    static std::string trim(std::string s) {
        auto a=s.find_first_not_of(" \t\r\n");
        return a==std::string::npos?std::string{}:s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);
    }
    static std::string lower(std::string s) {
        for(auto& c:s) if(c>='A'&&c<='Z') c=char(c-'A'+'a');
        return s;
    }
    static std::string value(std::string s) {
        char quote=0;
        for(size_t k=0;k<s.size();++k){
            if((s[k]=='\''||s[k]=='"')&&(k==0||s[k-1]!='\\')){
                if(!quote) quote=s[k];else if(quote==s[k]) quote=0;
            }
            if(!quote&&(s[k]==';'||s[k]=='#')&&(k==0||s[k-1]==' '||s[k-1]=='\t')){s.resize(k);break;}
        }
        s=trim(s);
        if(s.size()>=2&&((s.front()=='"'&&s.back()=='"')||(s.front()=='\''&&s.back()=='\''))) s=s.substr(1,s.size()-2);
        return s;
    }
public:
    bool load(const std::filesystem::path& path) {
        data_.clear();std::ifstream file(path,std::ios::binary);if(!file) return false;
        std::string line,section;bool first=true;
        while(std::getline(file,line)){
            if(first&&line.compare(0,3,"\xef\xbb\xbf")==0) line.erase(0,3);
            first=false;line=trim(line);
            if(line.empty()||line[0]==';'||line[0]=='#') continue;
            if(line.front()=='['){auto end=line.find(']');if(end!=std::string::npos) section=trim(line.substr(1,end-1));continue;}
            auto at=line.find('=');
            if(at!=std::string::npos){auto key=trim(line.substr(0,at));if(!key.empty()) data_[lower(section+"."+key)]=value(line.substr(at+1));}
        }
        return !file.bad();
    }
    std::string get(const std::string& key,std::string def={}) const {
        auto it=data_.find(lower(key));return it==data_.end()?def:it->second;
    }
    float number(const std::string& key,float def) const {
        auto text=get(key);std::istringstream stream(text);stream.imbue(std::locale::classic());
        float result=0;if(!(stream>>result)||!std::isfinite(result)) return def;
        stream>>std::ws;return stream.eof()?result:def;
    }
    bool boolean(const std::string& key,bool def) const {
        auto text=lower(get(key));
        if(text=="true"||text=="yes"||text=="on"||text=="1") return true;
        if(text=="false"||text=="no"||text=="off"||text=="0") return false;
        return def;
    }
    std::optional<uint64_t> parsedOffset(const std::string& key) const {
        auto text=get(key);
        if(text.empty()||text.front()=='-'||text.front()=='+') return {};
        try {
            size_t n=0;int base=text.size()>2&&text[0]=='0'&&(text[1]=='x'||text[1]=='X')?16:10;
            auto result=std::stoull(text,&n,base);return n==text.size()?std::optional<uint64_t>(result):std::nullopt;
        } catch(...){return {};}
    }
    uint64_t offset(const std::string& key) const {return parsedOffset(key).value_or(0);}
    bool contains(const std::string& key) const {return data_.count(lower(key))>0;}
};
struct Settings {
    bool esp=true,names=true,teamLabels=false,distances=true,skeleton=false,health=true,healthNumbers=true;
    bool filled=false,outline=true,headCircle=false,snaplines=false,offscreen=true,radar=false;
    bool teamCheck=false,deadCheck=true,watermark=true,crosshair=false,fovCircle=true,targetLine=true;
    bool vsync=true,onlineAvatar=true,accountFooter=true;
    int readerHz=30,cacheMs=900,idleFps=30,monitorHz=144;
    RadarOptions radarStyle{};
    RecoilOptions recoil{};
    int boxStyle=2,healthPosition=0,snapOrigin=0,frameCap=144;
    float maxDistance=2000,thickness=1.5f,fillOpacity=0.09f,radarRange=300,textSize=14;
    float boxOffsetX=0,boxOffsetY=0,nameOffsetY=-5,distOffsetY=4,healthBarOffsetX=0;
    std::array<float,4> enemy{0.9f,0.9f,0.94f,1.f},friendly{0.49f,0.97f,0.7f,1.f},selected{0.66f,0.42f,1.f,1.f};
    AimOptions aim{};
    void clamp() {
        static const Settings defaults;
        auto limit=[](float& v,float lo,float hi,float fallback){v=std::clamp(std::isfinite(v)?v:fallback,lo,hi);};
        boxStyle=std::clamp(boxStyle,0,3);healthPosition=std::clamp(healthPosition,0,2);
        snapOrigin=std::clamp(snapOrigin,0,2);frameCap=std::clamp(frameCap,30,300);
        limit(maxDistance,10,10000,defaults.maxDistance);limit(thickness,1,4,defaults.thickness);
        limit(fillOpacity,0,.4f,defaults.fillOpacity);limit(radarRange,25,2000,defaults.radarRange);limit(textSize,10,22,defaults.textSize);
        limit(boxOffsetX,-100,100,0);limit(boxOffsetY,-100,100,0);limit(nameOffsetY,-40,10,-5);limit(distOffsetY,-10,30,4);limit(healthBarOffsetX,-20,20,0);
        limit(aim.radius,20,650,defaults.aim.radius);limit(aim.smoothingMs,0,300,defaults.aim.smoothingMs);
        limit(aim.gain,.05f,4,defaults.aim.gain);limit(aim.maxStep,1,100,defaults.aim.maxStep);
        limit(aim.maxDistance,10,10000,defaults.aim.maxDistance);limit(aim.leadMs,0,250,defaults.aim.leadMs);
        aim.bone=std::clamp(aim.bone,0,3);aim.priority=std::clamp(aim.priority,0,2);
        aim.inputMode=std::clamp(aim.inputMode,0,1);aim.origin=std::clamp(aim.origin,0,1);aim.activation=std::clamp(aim.activation,0,3);
        limit(aim.deadzone,0,20,defaults.aim.deadzone);limit(aim.maxSpeed,50,5000,defaults.aim.maxSpeed);
        limit(aim.axisX,0,2,1);limit(aim.axisY,0,2,1);limit(aim.switchDelayMs,0,500,0);limit(aim.minHealth,0,10000,0);
        readerHz=std::clamp(readerHz,10,60);cacheMs=std::clamp(cacheMs,250,2500);idleFps=std::clamp(idleFps,10,60);monitorHz=std::clamp(monitorHz,30,360);
        radarStyle.shape=std::clamp(radarStyle.shape,0,1);radarStyle.orientation=std::clamp(radarStyle.orientation,0,1);radarStyle.corner=std::clamp(radarStyle.corner,0,3);
        limit(radarStyle.size,140,340,210);limit(radarStyle.opacity,.2f,1,.9f);limit(radarStyle.dotSize,2,8,4);
        recoil.mode=std::clamp(recoil.mode,0,1);limit(recoil.horizontal,-600,600,0);limit(recoil.vertical,-600,600,75);
        limit(recoil.delayMs,0,500,50);limit(recoil.maxStep,1,100,18);
        static thread_local std::string checkedPattern;static thread_local bool patternValid=false;
        if(checkedPattern!=recoil.pattern){checkedPattern=recoil.pattern;patternValid=bool(parsePattern(recoil.pattern));}
        if(!patternValid) recoil.pattern=defaults.recoil.pattern;
        for(int k=0;k<4;++k){limit(enemy[k],0,1,defaults.enemy[k]);limit(friendly[k],0,1,defaults.friendly[k]);limit(selected[k],0,1,defaults.selected[k]);}
    }
    bool load(const std::filesystem::path& path) {
        Ini ini;if(!ini.load(path)) return false;
        Settings next;bool recognized=false;
        auto b=[&](const char* key,bool& v){recognized|=ini.contains(key);v=ini.boolean(key,v);};
        auto f=[&](const char* key,float& v){recognized|=ini.contains(key);v=ini.number(key,v);};
        auto n=[&](const char* key,int& v){recognized|=ini.contains(key);v=int(std::clamp(ini.number(key,float(v)),-100000.f,100000.f));};
#define B(x) b("Visuals." #x,next.x)
        B(esp);B(names);B(teamLabels);B(distances);B(skeleton);B(health);B(healthNumbers);B(filled);B(outline);
        B(headCircle);B(snaplines);B(offscreen);B(radar);B(teamCheck);B(deadCheck);B(watermark);B(crosshair);B(fovCircle);B(targetLine);
#undef B
#define F(x) f("Visuals." #x,next.x)
        F(maxDistance);F(thickness);F(fillOpacity);F(radarRange);F(textSize);F(boxOffsetX);F(boxOffsetY);F(nameOffsetY);F(distOffsetY);F(healthBarOffsetX);
#undef F
        n("Visuals.boxStyle",next.boxStyle);n("Visuals.healthPosition",next.healthPosition);n("Visuals.snapOrigin",next.snapOrigin);
        b("System.vsync",next.vsync);n("System.frameCap",next.frameCap);n("System.monitorHz",next.monitorHz);
        b("System.onlineAvatar",next.onlineAvatar);b("System.accountFooter",next.accountFooter);n("System.readerHz",next.readerHz);n("System.cacheMs",next.cacheMs);n("System.idleFps",next.idleFps);
#define AB(x) b("Aim." #x,next.aim.x)
        AB(enabled);AB(teamCheck);AB(sticky);AB(prediction);
#undef AB
#define AF(x) f("Aim." #x,next.aim.x)
        AF(radius);AF(smoothingMs);AF(gain);AF(maxStep);AF(maxDistance);AF(leadMs);AF(deadzone);AF(maxSpeed);AF(axisX);AF(axisY);AF(switchDelayMs);AF(minHealth);
#undef AF
#define AN(x) n("Aim." #x,next.aim.x)
        AN(bone);AN(priority);AN(inputMode);AN(origin);AN(activation);
#undef AN
        n("Radar.shape",next.radarStyle.shape);n("Radar.orientation",next.radarStyle.orientation);n("Radar.corner",next.radarStyle.corner);
        f("Radar.size",next.radarStyle.size);f("Radar.opacity",next.radarStyle.opacity);f("Radar.dotSize",next.radarStyle.dotSize);
        b("Radar.edgeMarkers",next.radarStyle.edgeMarkers);b("Radar.labels",next.radarStyle.labels);b("Radar.altitude",next.radarStyle.altitude);b("Radar.rings",next.radarStyle.rings);
        b("Recoil.enabled",next.recoil.enabled);n("Recoil.mode",next.recoil.mode);f("Recoil.horizontal",next.recoil.horizontal);f("Recoil.vertical",next.recoil.vertical);
        f("Recoil.delayMs",next.recoil.delayMs);f("Recoil.maxStep",next.recoil.maxStep);recognized|=ini.contains("Recoil.pattern");next.recoil.pattern=ini.get("Recoil.pattern",next.recoil.pattern);
        for(auto entry:std::array<std::pair<const char*,std::array<float,4>*>,3>{{{"enemy",&next.enemy},{"friendly",&next.friendly},{"selected",&next.selected}}}){
            for(int k=0;k<4;++k){auto key=std::string("Colors.")+entry.first+std::to_string(k);recognized|=ini.contains(key);(*entry.second)[k]=ini.number(key,(*entry.second)[k]);}
        }
        if(!recognized) return false;
        next.clamp();*this=next;return true;
    }
    bool save(const std::filesystem::path& path) const {
        static std::atomic<uint64_t> serial{0};
        auto temporary=path;
        temporary += ".tmp-"+std::to_string(Clock::now().time_since_epoch().count())+"-"+std::to_string(serial++);
        std::ofstream out(temporary,std::ios::binary);if(!out) return false;
        Settings safe=*this;safe.clamp();
        out.imbue(std::locale::classic());out<<std::setprecision(7)<<"; Local settings only. No credentials.\n[Visuals]\n";
#define W(x) out<<#x "="<<safe.x<<"\n"
        W(esp);W(names);W(teamLabels);W(distances);W(skeleton);W(health);W(healthNumbers);W(filled);W(outline);
        W(headCircle);W(snaplines);W(offscreen);W(radar);W(teamCheck);W(deadCheck);W(watermark);W(crosshair);W(fovCircle);
        W(targetLine);W(maxDistance);W(thickness);W(fillOpacity);W(radarRange);W(textSize);W(boxOffsetX);W(boxOffsetY);W(nameOffsetY);W(distOffsetY);W(healthBarOffsetX);W(boxStyle);W(healthPosition);W(snapOrigin);
        out<<"[System]\n";W(vsync);W(frameCap);W(onlineAvatar);W(accountFooter);W(readerHz);W(cacheMs);W(idleFps);W(monitorHz);
#undef W
        out<<"[Aim]\n";
#define W(x) out<<#x "="<<safe.aim.x<<"\n"
        W(enabled);W(teamCheck);W(sticky);W(prediction);W(radius);W(smoothingMs);W(gain);W(maxStep);W(maxDistance);
        W(leadMs);W(bone);W(priority);W(inputMode);W(origin);W(activation);W(deadzone);W(maxSpeed);W(axisX);W(axisY);W(switchDelayMs);W(minHealth);
#undef W
        out<<"[Radar]\n";
#define RW(x) out<<#x "="<<safe.radarStyle.x<<"\n"
        RW(shape);RW(orientation);RW(corner);RW(size);RW(opacity);RW(dotSize);RW(edgeMarkers);RW(labels);RW(altitude);RW(rings);
#undef RW
        out<<"[Recoil]\n";
#define RW(x) out<<#x "="<<safe.recoil.x<<"\n"
        RW(enabled);RW(mode);RW(horizontal);RW(vertical);RW(delayMs);RW(maxStep);RW(pattern);
#undef RW
        out<<"[Colors]\n";
        for(auto entry:std::array<std::pair<const char*,const std::array<float,4>*>,3>{{{"enemy",&safe.enemy},{"friendly",&safe.friendly},{"selected",&safe.selected}}})
            for(int k=0;k<4;++k) out<<entry.first<<k<<"="<<(*entry.second)[k]<<"\n";
        out.flush();bool written=bool(out);out.close();written=written&&!out.fail();
        std::error_code error;
        if(written){
#ifdef _WIN32
            written=MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=FALSE;
#else
            std::filesystem::rename(temporary,path,error);written=!error;
#endif
        }
        if(!written) std::filesystem::remove(temporary,error);
        return written;
    }
};
}
