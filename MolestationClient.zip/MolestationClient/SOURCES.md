# Source and dependency record

## Application implementation

`src/`, `tests/`, the build scripts, and CMake project are supplied as editable source. The package includes no third-party injector or compiled cheat component.

The menu design follows the user-provided reference's visual layout. The avatar preview is drawn procedurally with Dear ImGui primitives. The original reference screenshot is not included in the package.

## Dear ImGui

- Official repository: https://github.com/ocornut/imgui
- Release: `v1.91.9b`
- Pinned commit: `f5befd2d29e66809cd1110a152e375a7f1981f06`
- Bundled: core files and Win32 / DX11 backends
- License: `vendor/imgui/LICENSE.txt` (MIT)
- Gamepad polling is disabled for this application.

## Inter

- Official Google Fonts distribution: https://github.com/google/fonts/tree/main/ofl/inter
- Original variable font, unmodified
- SHA-256: `29160a80ff49ddcab2c97711247e08b1fab27a484a329ce8b813d820dc559031`
- License: `assets/Inter-LICENSE.txt` (SIL OFL 1.1)

## Public Roblox layout reference

- Repository: [1](https://github.com/AtaberkCelil/RobloxExternalBase)
- Pinned layout commit: `10c6deaf57f241865f2e8e5585437bb3ca0f3062`
- Layout path: `External/src/sdk/offsets.h`
- Declared build: `version-4310300497aa4917`
- Full URL, retrieved date, and upstream file hash: `profiles/SOURCE.json`
- **Runtime-verified against current live Roblox: No**

Only the numeric fields needed by this reader were transcribed into an INI profile. This is provenance for an unverified public layout, not an endorsement or proof that it works. No source from that repository is compiled into this application.

## Runtime dependencies

The supplied Windows x64 executable imports standard Windows libraries: Direct3D 11, the Windows shader compiler, DWM, GDI, Kernel32, the system C runtime, Shell32, and User32. ImGui dynamically uses standard system DPI/DWM functions where available. The executable does not make network requests.

The build script resolves an installed local compiler and SDK. All source dependencies and assets are already in the archive.

## Current numeric profile update

The current profile targets `version-02c37bc51a384b8f` using rbxoffsets exact-build final JSON, retrieved 2026-10-01. The previous pinned source above is historical and is recorded separately in `profiles/SOURCE-OLD-431030.json`. Current source: https://www.rbxoffsets.com/api/v1/windows/offsets/version-02c37bc51a384b8f/final/offsets.json . SHA-256: `dd5fa2364ca7d90da2201cd230258fff74fcecb0fb5e827df504e8384e28c8b0`. Only mapped numeric data is consumed by the application. No downloaded binary or injection component is included. The data is not runtime-verified by this application.

## Optional public avatar service (1.1.0)

The application uses https://thumbnails.roblox.com/v1/users/avatar for public full-body thumbnail metadata and HTTPS Roblox CDN image URLs only. WinHTTP transports the request; Windows WIC decodes it. No new external binary/library is bundled for this feature. A procedural bacon-hair fallback is application source, not downloaded artwork.
