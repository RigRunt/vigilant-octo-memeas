# Molestation Client

External overlay for Roblox. Built on the Nexra External engine.

## Features

- ESP: box, skeleton, health bar, name tag, distance, tracers, head circle, offscreen arrows
- **Customizable ESP element offsets** — box X/Y, name Y, distance Y, health bar X, all live sliders in Players tab
- **Monitor Hz setting** — set your actual refresh rate; ESP reader pacing derives from it automatically
- **Username lock badge** — overlay always shows active account name top-right and in watermark
- Aimbot: FOV, smoothing, prediction, multi-bone targeting, sticky lock, relative/absolute modes
- Recoil compensation: steady rate or custom pattern
- Radar: circle/square, north/camera up, edge markers, altitude indicators
- Profiles: 3 preset slots + save/load defaults

## Controls

| Key | Action |
|-----|--------|
| Insert | Toggle menu |
| End | Exit |
| RMB (default) | Hold to aim |

## Build

```
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

Binary lands in `build/Release/MolestationClient.exe`

## Settings

`settings.ini` in the exe folder. Auto-saved on exit.

Monitor Hz: set in Options → Display → Monitor Hz. Default 144.
