@echo off
cd /d "%~dp0"
if not exist MolestationClient.exe (
  echo MolestationClient.exe is missing. Run build.bat first.
  pause
  exit /b 1
)
start "" "%~dp0MolestationClient.exe" --demo
